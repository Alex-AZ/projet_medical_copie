package com.m2i.demomedical;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemomedicalApplicationTests {

    @Test
    void contextLoads() {
    }

}
