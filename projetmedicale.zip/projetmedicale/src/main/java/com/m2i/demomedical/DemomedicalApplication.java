package com.m2i.demomedical;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemomedicalApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemomedicalApplication.class, args);
    }

}
