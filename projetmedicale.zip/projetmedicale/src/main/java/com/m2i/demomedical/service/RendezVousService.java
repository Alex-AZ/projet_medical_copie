package com.m2i.demomedical.service;

import com.m2i.demomedical.entities.PatientEntity;
import com.m2i.demomedical.entities.RendezVousEntity;
import com.m2i.demomedical.repository.RendezVousRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Date;

@Service
public class RendezVousService {

    @Autowired
    private RendezVousRepository rr;

    public RendezVousService(RendezVousRepository rr) {
        this.rr = rr;
    }

    public Iterable<RendezVousEntity> getList(){
        return rr.findAll();
    }

    private void  checkRdv( String dateheure, String type, String duree , String note ) throws Exception {
        if( dateheure.length() < 2 ){
            throw new Exception("Invalid value for date and hours");
        }

        if( type.length() < 2 ){
            throw new Exception("Invalid value for type");
        }

        if( duree.length() < 2 ){
            throw new Exception("Invalid value for duration");
        }

        if( note.length() < 2 ){
            throw new Exception("Invalid value for note");
        }
    }

    public RendezVousEntity addRdv(Date id_patient, String dateheure, String type, String duree , String note  ) throws Exception {
        checkRdv( dateheure, type, duree , note );
        RendezVousEntity r = new RendezVousEntity();
        r.setDateheure(Date.valueOf(dateheure));
        r.setType(type);
        r.setDuree(Integer.parseInt(duree));
        r.setNote(note);
        PatientEntity patientP = new PatientEntity();
        patientP.setId( Integer.parseInt(String.valueOf(id_patient)));
        r.setIdPatient( patientP );
        rr.save( r );

        return r;
    }

    public RendezVousEntity editRdv(int idr, String dateheure, String type, String duree, String note , int id_patient ) throws Exception {
        checkRdv( dateheure, type, duree , note );

        RendezVousEntity r = rr.findById(idr).get();
        r.setDateheure(Date.valueOf(dateheure));
        r.setType(type);
        r.setDuree(Integer.parseInt(duree));
        r.setNote(note);
        PatientEntity patientP = new PatientEntity();
        patientP.setId( id_patient );
        r.setIdPatient( patientP );
        rr.save( r );
        return r;
    }

    public RendezVousEntity find(int id) {
        return rr.findById( id ).get();
    }

    /* public RendezVousEntity findByEmail(String email) {
        try {
            return pr.findByEmail( email ).get();
        }catch( Exception e ) {
            return null;
        }

    }*/

    public void delete(int id) {
        rr.deleteById(id);
    }
}
