package com.m2i.demomedical.repository;

import com.m2i.demomedical.entities.RendezVousEntity;
import org.springframework.data.repository.CrudRepository;

public interface RendezVousRepository extends CrudRepository<RendezVousEntity, Integer> {
}
