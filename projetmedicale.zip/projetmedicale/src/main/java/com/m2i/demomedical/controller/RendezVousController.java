package com.m2i.demomedical.controller;

import com.m2i.demomedical.entities.PatientEntity;
import com.m2i.demomedical.entities.RendezVousEntity;
import com.m2i.demomedical.helpers.LoggingHelper;
import com.m2i.demomedical.service.PatientService;
import com.m2i.demomedical.service.RendezVousService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.ResponseEntity.BodyBuilder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.server.ResponseStatusException;

import java.sql.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/rdv")
public class RendezVousController {


    @Autowired
    final private LoggingHelper lh;

    @Autowired
    final private RendezVousService rs;

    @Autowired
    final private PatientService ps;

    public RendezVousController(LoggingHelper lh, RendezVousService rs, PatientService ps) {
        this.lh = lh;
        this.rs = rs;
        this.ps = ps;
    }

    @GetMapping("")
    public String listRdv( Model model ){
        model.addAttribute( "liste_rdv" , rs.getList() );
        model.addAttribute( "liste_patients" , ps.getList() );
        List<PatientEntity> lpatients = (List<PatientEntity>) ps.getList();
        System.out.println( lpatients.size() );
        return "rdv/list";
    }

    @GetMapping("/add")
    public String addRdvGet( Model model ){
        model.addAttribute( "entete_titre" , "Ajouter un rendez-vous" );
        model.addAttribute( "liste_patients" , ps.getList() );
        model.addAttribute( "r" , new RendezVousEntity());
        return "rdv/add_edit";
    }

    @PostMapping("/add")
    public String addRdvPost( HttpServletRequest request, Model model  ){
        String idpatient = request.getParameter("idpatient");
        String datetime = request.getParameter("datetime");
        String type = request.getParameter("type");
        String duration = request.getParameter("duration");
        String note = request.getParameter("note");

        try{
            rs.addRdv(Date.valueOf(datetime), type, duration, note, idpatient );
            return "redirect:/rdv?success";
        }catch( Exception e ){

            model.addAttribute("error" , e.getMessage() );

            // Récupérer les anciens paramètres
            /*RendezVousEntity rerreur = new RendezVousEntity();
            rerreur.setIdPatient(id_patient);*/

            /*model.addAttribute( "r" , rerreur );*/

            return "rdv/add_edit";
        }
    }

    @GetMapping("/edit/{id}")
    public String editRdvGet( Model model , @PathVariable int id ){
        try{
            model.addAttribute( "entete_titre" , "Editer un rendez-vous" );
            model.addAttribute( "liste_patients" , ps.getList() );
            model.addAttribute( "r" , rs.find(id) );
            return "rdv/add_edit";
        }catch ( Exception e ){
            return "redirect:/rdv?error="+e.getMessage();
        }
    }

    @PostMapping("/edit/{id}")
    public String editRdvPost( HttpServletRequest request , @PathVariable int id ){

        try{
            String idpatient = request.getParameter("idpatient");
            String datetime = request.getParameter("datetime");
            String type = request.getParameter("type");
            String duration = request.getParameter("duration");
            String note = request.getParameter("note");

            rs.editRdv(id, idpatient, datetime, type, duration , Integer.parseInt(note));
            return "redirect:/rdv?success";
        }catch( Exception e ){
            return "rdv/add_edit";
        }
    }

    @DeleteMapping("/delete/{id}")
    @ResponseBody
    public BodyBuilder deleteRdv( @PathVariable int id ){
        try{
            rs.delete(id);
            return ResponseEntity.ok() ;
        }catch( Exception e ){
            throw new ResponseStatusException( HttpStatus.BAD_REQUEST , e.getMessage() );
        }
    }

    /*@GetMapping("/check")
    @ResponseBody
    public Boolean checkRdvExists( HttpServletRequest request ){
        String emailParam = request.getParameter("email");
        System.out.println( emailParam );
        PatientEntity patient = ps.findByEmail( emailParam );

        return patient != null;
        //return "common/error";
    }*/
}
