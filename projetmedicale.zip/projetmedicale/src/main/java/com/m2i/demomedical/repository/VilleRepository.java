package com.m2i.demomedical.repository;

import com.m2i.demomedical.entities.VilleEntity;
import org.springframework.data.repository.CrudRepository;

public interface VilleRepository extends CrudRepository<VilleEntity, Integer> {
}
